"""
Firehose Data Transformation Lambda — CloudWatch Logs Decompressor

CloudWatch Logs subscription filters send gzip-compressed records to Firehose.
This Lambda decompresses the CloudWatch envelope and extracts individual log
events as NDJSON lines, so Auto Loader can read them as plain JSON.

Each CloudWatch record has the format:
{
    "messageType": "DATA_MESSAGE",
    "owner": "...",
    "logGroup": "...",
    "logStream": "...",
    "subscriptionFilters": ["..."],
    "logEvents": [
        {"id": "...", "timestamp": 1234, "message": "..."},
        ...
    ]
}

This Lambda extracts each logEvent.message, wraps it with metadata
(logGroup, logStream, timestamp), and returns NDJSON for Firehose to write.
"""

import base64
import gzip
import json


def handler(event, context):
    """Firehose data transformation handler."""
    output_records = []

    for record in event["records"]:
        record_id = record["recordId"]

        try:
            # Firehose passes base64-encoded data
            raw = base64.b64decode(record["data"])

            # CloudWatch Logs subscription filter sends gzip-compressed JSON
            try:
                decompressed = gzip.decompress(raw)
            except Exception:
                # Not gzip — pass through as-is
                decompressed = raw

            payload = json.loads(decompressed)

            # Skip control messages (CloudWatch sends these periodically)
            if payload.get("messageType") == "CONTROL_MESSAGE":
                output_records.append({
                    "recordId": record_id,
                    "result": "Dropped",
                    "data": record["data"],
                })
                continue

            # Extract log events and emit as NDJSON
            log_group = payload.get("logGroup", "")
            log_stream = payload.get("logStream", "")
            log_events = payload.get("logEvents", [])

            if not log_events:
                output_records.append({
                    "recordId": record_id,
                    "result": "Dropped",
                    "data": record["data"],
                })
                continue

            # Build NDJSON: one JSON line per log event
            lines = []
            for evt in log_events:
                line = json.dumps({
                    "timestamp": evt.get("timestamp"),
                    "message": evt.get("message", ""),
                    "log_group": log_group,
                    "log_stream": log_stream,
                    "event_id": evt.get("id", ""),
                }, separators=(",", ":"))
                lines.append(line)

            # Join with newlines — Firehose will concatenate records
            ndjson = "\n".join(lines) + "\n"

            output_records.append({
                "recordId": record_id,
                "result": "Ok",
                "data": base64.b64encode(ndjson.encode("utf-8")).decode("utf-8"),
            })

        except Exception as e:
            # On error, mark as processing failed (Firehose retries or sends to error prefix)
            output_records.append({
                "recordId": record_id,
                "result": "ProcessingFailed",
                "data": record["data"],
            })

    return {"records": output_records}
